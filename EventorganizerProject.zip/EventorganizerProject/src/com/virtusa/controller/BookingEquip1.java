
package com.virtusa.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.bean.EquipBean;
import com.virtusa.Dao.*;
import java.io.PrintWriter;  
@WebServlet("/BookingEquipment1")  
public class  BookingEquip1 extends HttpServlet {  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)   
          throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
          
        String sid=request.getParameter("equipId");  
        int id=Integer.parseInt(sid);  
        String name=request.getParameter("equipName");  
       String scost=request.getParameter("equipCost"); 
        int cost=Integer.parseInt(scost); 
        EquipBean e=new EquipBean();  
        e.setEquipId(id);  
        e.setEquipName(name);  
        e.setEquipCost(cost);  
        int status=BookingEquipmentDao.save(e);  
        if(status>0){  
        	  out.println(" record  booked"); 
        }else{  
            out.println("Sorry! unable to book record");  
        }  
          
        out.close();  
    }  
  
}  
