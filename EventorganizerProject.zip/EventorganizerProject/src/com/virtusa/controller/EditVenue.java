package com.virtusa.controller;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.Service.VenueService;
import com.virtusa.bean.VenueBean;



@WebServlet("/EditServlet")
public class EditVenue extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h1>Update venue</h1>");
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		
		
		VenueService ob=new	VenueService();
		VenueBean e=ob.editVenue(id);
		out.print("<form action='./EditServlet2' method='post'>");
		out.print("<table>");
		out.print("<tr><td></td><td><input type='hidden' name='venueId' value='"+e.getVenueId()+"'/></td></tr>");
		out.print("<tr><td>venueName:</td><td><input type='text' name='venueName' value='"+e.getVenueName()+"'/></td></tr>");
		out.print("<tr><td>venueCost:</td><td><input type='text' name='venueCost' value='"+e.getVenueCost()+"'/></td></tr>");
		out.print("<tr><td>venueContact:</td><td><input type='text' name='venueContact' value='"+e.getVenueContact()+"'/></td></tr>");
		
		out.print("<tr><td colspan='2'><input type='submit' value='Edit &amp; Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");
		
		out.close();
	
	}
}