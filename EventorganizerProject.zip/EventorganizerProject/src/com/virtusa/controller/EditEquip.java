package com.virtusa.controller;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.Dao.EquipDao1;
import com.virtusa.Dao.VenueDao;
import com.virtusa.Service.EquipService;
import com.virtusa.bean.EquipBean;
import com.virtusa.bean.VenueBean;



@WebServlet("/EditEquip")
public class EditEquip extends HttpServlet {
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

response.setContentType("text/html");
PrintWriter out=response.getWriter();
out.println("<h1>Update Equip</h1>");
String sid=request.getParameter("id");
int id=Integer.parseInt(sid);


EquipService ob=new EquipService();
EquipBean e=ob.editEquip(id);

out.print("<form action='./EditEquip2' method='post'>");
out.print("<table>");
out.print("<tr><td><input type='hidden' name='equipId' value='"+e.getEquipId()+"'/></td></tr>");
out.print("<tr><td>equipName:</td><td><input type='text' name='equipName' value='"+e.getEquipName()+"'/></td></tr>");
out.print("<tr><td>equipCost:</td><td><input type='text' name='equipCost' value='"+e.getEquipCost()+"'/></td></tr>");

out.print("<tr><td colspan='2'><input type='submit' value='Edit &amp; Save '/></td></tr>");
out.print("</table>");
out.print("</form>");

out.close();

}
}