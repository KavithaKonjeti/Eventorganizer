package com.virtusa.controller;


import java.io.IOException;  
import java.io.PrintWriter;  
import java.util.List;  
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;
import com.virtusa.bean.EventBean;
import com.virtusa.Dao.*;
@WebServlet("/Book1")
public class ViewBookingType extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();

		out.println("<h1>Booking list</h1>");
		
		List<EventBean> list=Eventtype.getAllFullDetails();
		
		out.print("<table border='1' width='100%'");
		out.print("<tr><th>venueId</th><th>venueName</th><th>equipName</th><th>foodName</th><th>eventtype</th><th>eventdate</th></tr>");
		for(EventBean e:list){
			out.print("<tr><td>"+e.getVenueId()+"</td><td>"+e.getVenueName()+"</td><td>"+e.getEquipName()+"</td><td>"+e.getFoodName()+"</td><td>"+e.getEventtype()+"</td><td>"+e.getEventdate()+"</td></tr>");
		}
		out.print("</table>");
		
		out.close();
	}
}