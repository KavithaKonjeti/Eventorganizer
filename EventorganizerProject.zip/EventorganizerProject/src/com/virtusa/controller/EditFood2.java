package com.virtusa.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.Dao.FoodDao;
import com.virtusa.Service.FoodService;
import com.virtusa.bean.FoodBean;


import java.io.PrintWriter;  
  
@WebServlet("/EditFood2")  
public class EditFood2 extends HttpServlet {  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)   
          throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
          
        String sid=request.getParameter("foodId");  
        int id=Integer.parseInt(sid);  
        String name=request.getParameter("foodName");  
       String scost=request.getParameter("foodCost"); 
        int cost=Integer.parseInt(scost);
        
      FoodBean e=new FoodBean();  
        e.setFoodId(id);  
        e.setFoodName(name);  
        e.setFoodCost(cost);  
       
          

        FoodService ob=new FoodService();
        int status=ob.editFood2(e);
        if(status>0){  
            response.sendRedirect("ViewFood");  
        }else{  
            out.println("Sorry! unable to update record");  
        }  
          
        out.close();  
    }  
  
}