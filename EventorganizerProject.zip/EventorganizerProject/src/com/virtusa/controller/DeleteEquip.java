package com.virtusa.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.Dao.EquipDao1;
import com.virtusa.Dao.VenueDao;
import com.virtusa.Service.EquipService;

  
@WebServlet("/DeleteEquip")  
public class DeleteEquip extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)  
             throws ServletException, IOException {  
        String sid=request.getParameter("id");  
        int equipId=Integer.parseInt(sid);  

        EquipService ob=new EquipService();
        ob.equipDelete(equipId);
        response.sendRedirect("ViewEquip");  
    }  
} 
