
	package com.virtusa.controller;
	import java.io.IOException;
	import java.io.PrintWriter;
	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import com.virtusa.Dao.*;
import com.virtusa.bean.*;
	@WebServlet("/BookingFood")
	public class BookingFood extends HttpServlet {
		 protected void doGet(HttpServletRequest request, HttpServletResponse response)   
		          throws ServletException, IOException {  
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h1>Book Food</h1>");
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		
		FoodBean e=BookingFoodDao.getFoodById(id);

		out.print("<form action='./BookingFood1' method='post'>");
		out.print("<table>");
		out.print("<tr><td>FoodId:</td><td><input type='text' name='foodId' value='"+e.getFoodId()+"'/></td></tr>");
		out.print("<tr><td>FoodtName:</td><td><input type='text' name='foodName' value='"+e.getFoodName()+"'/></td></tr>");
		out.print("<tr><td>FoodCost:</td><td><input type='text' name='foodCost' value='"+e.getFoodCost()+"'/></td></tr>");
	
		out.print("<tr><td colspan='2'><input type='submit' value='Book &amp; Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");
		
		out.close();
		
		}
	}

