package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.sql.*;  
@WebServlet("/Register")
public class Register extends HttpServlet {  
	
public void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
	
  
response.setContentType("text/html");  
PrintWriter out = response.getWriter();  
          
String n=request.getParameter("Username");  
String p=request.getParameter("password");  
String e=request.getParameter("Conformpassword");  
String s=request.getParameter("email");  
String a=request.getParameter("Address");
String h=request.getParameter("Phno");
int c=Integer.parseInt(h); 
  
try{  
Class.forName("oracle.jdbc.driver.OracleDriver");  
Connection con=DriverManager.getConnection(  
"jdbc:oracle:thin:@localhost:1521:xe","system","kavitha");  
  
PreparedStatement ps=con.prepareStatement(  
"insert into register values(?,?,?,?,?,?)");  
  
ps.setString(1,n);  
ps.setString(2,p);  
ps.setString(3,e);  
ps.setString(4,s);  
ps.setString(5,a);
ps.setInt(6,c);
          
int i=ps.executeUpdate();  
if(i>0){
out.print("You are successfully registered...");  
response.sendRedirect("login.html");
}
else {
	out.print("failed to register");
	
}
	
          
}catch (Exception e2) {
	System.out.println(e2);
	}  
          
out.close();  
}  
  
}  

