package com.virtusa.controller;


import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.Service.FoodService;

  
@WebServlet("/DeleteFood")  
public class DeleteFood extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)   
             throws ServletException, IOException {  
        String sid=request.getParameter("id");  
        int id1=Integer.parseInt(sid);  

        FoodService ob=new FoodService();
        ob.deleteFood(id1);
        response.sendRedirect("ViewFood");  
    }  
} 

