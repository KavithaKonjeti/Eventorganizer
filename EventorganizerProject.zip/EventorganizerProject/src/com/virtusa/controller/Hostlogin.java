package com.virtusa.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import com.virtusa.Dao.UserDao;

@WebServlet("/hostlogin")
public class Hostlogin extends HttpServlet {
	static final Logger logger = Logger.getLogger(Hostlogin.class);
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException 
	{
		
		    response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	          
	    String n=request.getParameter("username");  
	    String p=request.getParameter("password"); 
	    HttpSession se = request.getSession();
	    se.setAttribute("username", n);
	          
	    if(UserDao.validate(n, p)){ 
	    	 response.sendRedirect("HostBooking");  
	        out.print("Login Successfull");
	    }  
	    else{  
	        out.print("Sorry username or password error");  
	        RequestDispatcher rd=request.getRequestDispatcher("login.html");  
	        rd.include(request,response);  
	    }  
	          
	    out.close();  
	    }  
	}  
