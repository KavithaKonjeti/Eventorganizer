package com.virtusa.bean;

public class EventBean{
     
	private String eventtype ;
    private String eventdate;
    private int venueId;
    private String venueName;
    private String equipName;
    private String foodName;
	public String getEventtype() {
		return eventtype;
	}
	public void setEventtype(String eventtype) {
		this.eventtype = eventtype;
	}
	public String getEventdate() {
		return eventdate;
	}
	
	public void setEventdate(String eventdate) {
		this.eventdate = eventdate;
	}
	public int getVenueId() {
		return venueId;
	}
	public void setVenueId(int venueId) {
		this.venueId = venueId;
	}
	public String getVenueName() {
		return venueName;
	}
	public void setVenueName(String venueName) {
		this.venueName = venueName;
	}
	public String getEquipName() {
		return equipName;
	}
	public void setEquipName(String equipName) {
		this.equipName = equipName;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	@Override
	public String toString() {
		return "EventBean [eventtype=" + eventtype + ", eventdate=" + eventdate + ", venueId=" + venueId
				+ ", venueName=" + venueName + ", equipName=" + equipName + ", foodName=" + foodName
				+ ", getEventtype()=" + getEventtype() + ", getEventdate()=" + getEventdate() + ", getVenueId()="
				+ getVenueId() + ", getVenueName()=" + getVenueName() + ", getEquipName()=" + getEquipName()
				+ ", getFoodName()=" + getFoodName() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
	
}