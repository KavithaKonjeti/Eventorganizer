package com.virtusa.bean;
import java.io.IOException;

public class EquipBean {
private int equipId;
private String equipName;
private int equipCost;
public int getEquipId() {
return equipId;
}
public void setEquipId(int equipId) {
this.equipId = equipId;
}
public String getEquipName() {
return equipName;
}
public void setEquipName(String equipName) {
this.equipName = equipName;
}
public int getEquipCost() {
return equipCost;
}
public void setEquipCost(int equipCost) {
this.equipCost = equipCost;
}
@Override
public String toString() {
return "EquipBean [equipId=" + equipId + ", equipName=" + equipName + ", equipCost=" + equipCost
+ ", getEquipId()=" + getEquipId() + ", getEquipName()=" + getEquipName() + ", getEquipCost()="
+ getEquipCost() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
+ super.toString() + "]";
}
}