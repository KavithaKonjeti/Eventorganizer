package com.virtusa.Service;

import java.util.List;
import com.virtusa.Dao.VenueDao;
import com.virtusa.bean.VenueBean;

public class VenueService {

	public int save1(VenueBean e) {
		// TODO Auto-generated method stub
		int s=VenueDao.save(e);
		return s;
	}
	public List<VenueBean> viewvenue() {
		// TODO Auto-generated method stub
		List<VenueBean> list=VenueDao.getAllVenues();
		return list;
	}
	public VenueBean editVenue(int id) {
		// TODO Auto-generated method stub
		VenueBean e=VenueDao.getvenueById(id);
		return e;
	}
	public int editVenue2(VenueBean e) {
		// TODO Auto-generated method stub
		int s=VenueDao.update(e); 
		return s;
	}
	public void deleteVenue(int id) {
		// TODO Auto-generated method stub
		VenueDao.delete(id);
	}
	
	
       
}
