package com.virtusa.Dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.virtusa.bean.EventBean;
public class Eventtype {
	public static Connection getConnection(){  
        Connection con=null;  
        try{  
            Class.forName("oracle.jdbc.driver.OracleDriver");  
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","kavitha");  
          
        }catch(Exception e)
       {
   System.out.println(e);
    }  
        return con;  
    } 
	
	 public static int save(EventBean e){  
	        int s=0;
	        try{  
	            Connection con=Eventtype.getConnection();  
	    
	            PreparedStatement ps=con.prepareStatement("insert into Eventbook(venueId,venueName,equipName,foodName,eventtype,eventdate) values (?,?,?,?,?,?)");  
	            ps.setInt(1, e.getVenueId());
	            ps.setString(2,e.getVenueName());
	            ps.setString(3, e.getEquipName());
	            ps.setString(4, e.getFoodName());
	            ps.setString(5,e.getEventtype());  
	            ps.setString(6,e.getEventdate());  
	            System.out.print(e.getVenueName());
	             s=ps.executeUpdate();  
	             
	            con.close();  
	        }catch(Exception ex){
	        	ex.printStackTrace();}  
	          
	      
		return s;
	    }  
	   
	    public static List<EventBean> getAllFullDetails(){  
	        List<EventBean> list=new ArrayList<EventBean>();  
	          
	        try{  
	            Connection con=Eventtype.getConnection();  
	            PreparedStatement ps=con.prepareStatement("select * from Eventbook");  
	            ResultSet rs=ps.executeQuery();  
	            while(rs.next()){  
	               EventBean e=new EventBean();  
	               e.setVenueId(rs.getInt(1));
	               e.setVenueName(rs.getString(2));
	               e.setEquipName(rs.getString(3));
	               e.setFoodName(rs.getString(4));
	               e.setEventtype(rs.getString(5));
	               e.setEventdate(rs.getString(6));
	               
	                list.add(e);  
	            }  
	            con.close();  
	        }catch(Exception e){e.printStackTrace();}  
	          
	        return list;  
	    }  
	}  

			    
	    
	
	

