package com.virtusa.Dao;
import com.virtusa.bean.VenueBean;
import java.util.*;
import java.sql.*;  
  
public class VenueDao {  
  
    public static Connection getConnection(){  
        Connection con=null;  
        try{  
            Class.forName("oracle.jdbc.driver.OracleDriver");  
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","kavitha");  
        }catch(Exception e)
       {
   System.out.println(e);
    }  
        return con;  
    }  
    public static int save(VenueBean e){  
        int status=0;  
        try{  
            Connection con=VenueDao.getConnection();  
            PreparedStatement ps=con.prepareStatement("insert into viewmanagement(venueId,venueName,venueCost,venueContact) values (?,?,?,?)");  
       
            ps.setInt(1,e.getVenueId());  
            ps.setString(2,e.getVenueName());  
            ps.setInt(3,e.getVenueCost());  
            ps.setDouble(4,e.getVenueContact());  
            
            status=ps.executeUpdate();
            
            con.close();  
        }catch(Exception ex){
        	ex.printStackTrace();}  
          
        return status;  
    }  
    
    
    public static int update(VenueBean  e){  
        int status=0;  
        try{  
            Connection con=VenueDao.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "update viewmanagement set venueName=?,venueCost=?,venueContact=?where venueId=?");  
            
            ps.setString(1,e.getVenueName());  
            ps.setInt(2,e.getVenueCost());  
            ps.setInt(3,e.getVenueContact());  
           ps.setInt(4, e.getVenueId());
             
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){
        	ex.printStackTrace();}  
          
        return status;  
    }  

    	
    
    public static int delete(int venueId){  
        int status=0;  
        try{  
            Connection con=VenueDao.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from viewmanagement where venueId=?");  
            ps.setInt(1,venueId);  
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception e){
      e.printStackTrace();
       }  
          
        return status;  
    }  
    public static VenueBean getvenueById(int venueId){  
       VenueBean e=new VenueBean();  
          
        try{  
            Connection con=VenueDao.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from viewmanagement where venueId=?");  
            ps.setInt(1,venueId);  
            ResultSet rs=ps.executeQuery();  
            if(rs.next()){  
                e.setVenueId(rs.getInt(1));  
                e.setVenueName(rs.getString(2));  
                e.setVenueCost(rs.getInt(3));  
                e.setVenueContact(rs.getInt(4));  
                  
            }  
            con.close();  
        }catch(Exception ex){
        	ex.printStackTrace();}  
          
        return e;  
    }  
    public static List<VenueBean> getAllVenues(){  
        List<VenueBean> list=new ArrayList<VenueBean>();  
          
        try{  
            Connection con=VenueDao.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from viewmanagement");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
               VenueBean e=new VenueBean();  
                e.setVenueId(rs.getInt(1));  
                e.setVenueName(rs.getString(2));  
                e.setVenueCost(rs.getInt(3));  
                e.setVenueContact(rs.getInt(4));    
                list.add(e);  
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return list;  
    }  
}  
