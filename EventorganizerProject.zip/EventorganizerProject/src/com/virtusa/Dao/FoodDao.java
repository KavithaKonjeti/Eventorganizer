package com.virtusa.Dao;
	import com.virtusa.bean.FoodBean;
	import java.util.*;
		import java.sql.*;  	  
		public class FoodDao {  
		  
		    public static Connection getConnection(){  
		        Connection con=null;  
		        try{  
		            Class.forName("oracle.jdbc.driver.OracleDriver");  
		            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","kavitha");  
		        }catch(Exception e)
		       {
		   System.out.println(e);
		    }  
		        return con;  
		    }  
		    public static int save(FoodBean e){  
		        int status=0;
		        try{  
		            Connection con=FoodDao.getConnection();  
		       
		            PreparedStatement ps=con.prepareStatement("insert into foodmanagement(foodId,foodName,foodCost) values (?,?,?)");  
		         
		            ps.setInt(1,e.getFoodId());  
		            ps.setString(2,e.getFoodName());  
		            ps.setInt(3,e.getFoodCost());  
		             
		              
		            status=ps.executeUpdate();  
		              
		            con.close();  
		        }catch(Exception ex){
		        	ex.printStackTrace();}  
		          
		        return status;  
		    }  
		    
		    
		    public static int update(FoodBean  e){  
		        int status=0;  
		        try{  
		            Connection con=FoodDao.getConnection();  
		            PreparedStatement ps=con.prepareStatement(  
		                         "update foodmanagement set foodName=?,foodCost=?where foodId=?");  
		            
		            ps.setString(1,e.getFoodName());  
		            ps.setInt(2,e.getFoodCost());  
		            ps.setInt(3, e.getFoodId());
		             
		              
		            status=ps.executeUpdate();  
		              
		            con.close();  
		        }catch(Exception ex){
		        	ex.printStackTrace();}  
		          
		        return status;  
		    }  
		
		    public static int delete(int FoodId){  
		        int status=0;  
		        try{  
		            Connection con=FoodDao.getConnection();  
		            PreparedStatement ps=con.prepareStatement("delete from foodmanagement where FoodId=?");  
		            ps.setInt(1,FoodId);  
		            status=ps.executeUpdate();  
		              
		            con.close();  
		        }catch(Exception e){
		      e.printStackTrace();
		       }  
		          
		        return status;  
		    }  
		    public static FoodBean getFoodById(int foodId){  
		       FoodBean e=new  FoodBean();  
		          
		        try{  
		            Connection con=FoodDao.getConnection();  
		            PreparedStatement ps=con.prepareStatement("select * from foodmanagement where foodId=?");  
		            ps.setInt(1,foodId);  
		            ResultSet rs=ps.executeQuery();  
		            if(rs.next()){  
		                e.setFoodId(rs.getInt(1));  
		                e.setFoodName(rs.getString(2));  
		                e.setFoodCost(rs.getInt(3));  
		               
		                  
		            }  
		            con.close();  
		        }catch(Exception ex){
		        	ex.printStackTrace();}  
		          
		        return e;  
		    }  
		   
		  

		    public static List<FoodBean> getAllFood(){  
		        List<FoodBean> list=new ArrayList<FoodBean>();  
		          
		        try{  
		            Connection con=FoodDao.getConnection();  
		            PreparedStatement ps=con.prepareStatement("select * from foodmanagement");  
		            ResultSet rs=ps.executeQuery();  
		            while(rs.next()){  
		               FoodBean e=new FoodBean();  
		                e.setFoodId(rs.getInt(1));  
		                e.setFoodName(rs.getString(2));  
		                e.setFoodCost(rs.getInt(3));  
		                   
		                list.add(e);  
		            }  
		            con.close();  
		        }catch(Exception e){e.printStackTrace();}  
		          
		        return list;  
		    }  
		}  


